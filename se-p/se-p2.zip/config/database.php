﻿<?php
/**
 * Database Configuration - PRODUCTION
 * Website: https://smart-educ.infinityfreeapp.com
 * Account: if0_40155395
 */

// عدادات قاعدة البيانات
$host = "sql100.infinityfree.com";
$port = "3306";
$db_name = "if0_40155395_smartedu";
$username = "if0_40155395";
$password = "CbA9tiKj5CtBq";

// نشاء اتصال PDO
try {
    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$db_name};charset=utf8mb4",
        $username,
        $password
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("خط في الاتصال بقاعدة البيانات");
}

// Class للتوافق مع الكود القديم
class Database {
    private $host = "sql100.infinityfree.com";
    private $port = "3306";
    private $db_name = "if0_40155395_smartedu";
    private $username = "if0_40155395";
    private $password = "CbA9tiKj5CtBq";
    public $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            echo "Connection Error: " . $e->getMessage();
        }
        
        return $this->conn;
    }
}

function getDB() {
    global $pdo;
    return $pdo;
}
?>